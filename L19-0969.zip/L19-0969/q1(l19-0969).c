#include<stdio.h>

int main(int argc, char* argv[])
{
 FILE *fp;
 int count=0,a=0;
 int check=0;
 char tmp[100] = "\0";
 char arr[200] = "\0";
 char str[100];  //sub string
 if(argv[1][0]=='a')
 {
    fp = fopen("q1_a.txt","r");
 }
 else if(argv[1][0]=='b')
 {
    fp = fopen("q1_b.txt","r");
 }
 else
 {
    printf("Incorrect Name i.e. other than a,b\n");
    return 0;
 }
 if(fp==NULL)
 {
       printf("FIle not Found");
       return 0;
 }
 while (fgets(tmp,sizeof(tmp), fp) != NULL)
 {
        strcat(arr,tmp);
 }
 arr[strlen(arr)-1] = '\0';
 fclose(fp);
 printf("\n========================================\n");
 printf("\n\nOrignal array is\n%s",arr);
 int i=0;
 for(;i<strlen(argv[2]);i++)
 {
  str[i] = argv[2][i];  //str contain substring
 }      
 str[i]=0;
 printf("\n\nSubstring array is\n%s",str);
 i = 0;
 for (;arr[i]!=0; i++)
 {
	if (arr[i]==str[0])
	{
		a=i+1;
                int j= 1;
		for (;str[j]!=0 ; j++)
		{
			if (str[j]!=arr[a])
			{
				check=1;
				break;
			}
			a++;
		}
		if (check==0)  //we have found our substring
		{
			count++;			
                }
		check=0;   
       }
 }
 if (count==0)
 {
       printf("\n========================================\n");
       printf("Substing not found in a File\n");
       printf("\n========================================\n");
 }
 else
 {
       printf("\n=====================================\n");		 
       printf("Number of occurences of subsring in File is : %d",count);
       printf("\n========================================\n");
 }
return 0;
}
