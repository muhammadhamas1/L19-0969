#include<stdio.h>

int main(int argc, char* argv[])
{
 FILE *fp;
 int count=0,a=0,v=0,b=0,cnt=0,n=0;
 int check=0;
 char temp[50] = "\0";
 char tmp[100] = "\0";
 char arr[200] = "\0";
 char str[100];  //sub string
 char ch[100];
char newarr[200];
strcpy(newarr,"\0");
 if(argv[1][0]=='a')
 {
    fp = fopen("q1_a.txt","r");
 }
 else if(argv[1][0]=='b')
 {
    fp = fopen("q1_b.txt","r");
 }
 else
 {
    printf("Incorrect Name i.e. other than a,b\n");
    return 0;
 }
 if(fp==NULL)
 {
      printf("FIle not Found");
       return 0;
 }
 while (fgets(tmp,sizeof(tmp), fp) != NULL)
 {
        strcat(arr,tmp);
 }
 arr[strlen(arr)-1] = '\0';
 fclose(fp);
 printf("\n========================================\n");
 printf("\n\nOrignal array is\n%s",arr);
 int i=0;
 for(;i<strlen(arr)+1;i++)
 {
    if(arr[i]!=' ' && arr[i]!='\0')
    {
      str[n]=arr[i];  //word by word copy
      n++;
    }
    else if(arr[i]==' ' || arr[i] == '\0')
    {
      str[n]=0;
      cnt++;
      printf("\nStr %s",str);
      a=0;
      int j= 0;
      for (; str[j]!=0 ; j++)  //get each word by elements that are not vowels
      {
        if(str[j]=='e' || str[j]=='o' || str[j]=='i' || str[j]=='u' || str[j]=='a' || str[j]=='E' || str[j]=='O' || str[j]=='I' || str[j]=='U' ||  str[j]=='A'){}
        else
        {
	  ch[a]=str[j];
	  a++;
        }
       }
       ch[a]=0;
       printf("\nVal Ch %s",ch);
       int f= 0;
       for (; ch[f]!=0 ; f++)
       {
	  b++;  //count the number of elements to reverse
       }
       j= 0;
       for (; str[j]!=0 ; j++)  //reverse each word by elements that are not vowels
       {
	  if(str[j]=='e' || str[j]=='o' || str[j]=='i' || str[j]=='u' || str[j]=='a' || str[j]=='E' || str[j]=='O' || str[j]=='I' || str[j]=='U' || str[j]=='A' ){}
	   else
	   {
		str[j]=ch[b-1];
		b--;
	    }
	}
      //str="\0";
     printf("reverse str %s\n",str);
     strcat(newarr,str);
     strcat(newarr," ");
      n=0;
      strcpy(str,"\0");
    }
 }
     FILE *fp1;
     fp1 = fopen("output.txt","w"); 
     fprintf(fp1,"%s",newarr);
printf("value of count is%d",cnt);
return 0;
}



