#include<stdio.h>

int main(int argc, char* argv[])
{
   int i=0,c1=0;
   char c,a;
   char data[20][300];
   for(i=0;i<20;i++)
   {
     data[i][0] = '\0';
   }
   FILE *fp;
	printf("Press any Option : \n");
	printf("Press 'a' for adding students\n");
	printf("Press 'b' for reding students record\n");
	printf("Press 'c' for deleting students record\n");
	scanf("%c",&c );
	while (1)
	{
		if (c=='a')
		{
                        fp = fopen("student.txt","a+");
			printf("'a pressed'\n");
			printf("How many students you want to add\n");
			scanf("%d",&c1);
                        for(i=0;i<c1;i++){
                            char tmp[30];
                            printf("\nEnter name of student\n");
                            scanf("%s",&tmp);
                            fputs(tmp,fp);
                            fputc(' ',fp);
                            printf("\nEnter rollno of student\n");
                            scanf("%s",&tmp);
                            fputs(tmp,fp);
                            fputc(' ',fp);
                            printf("\nEnter email of student\n");
                            scanf("%s",&tmp);
                            fputs(tmp,fp);
                        }
                        fclose(fp);
                        printf("\nstudent added to the record successfully \n");
                        break;
		}
		else if (c=='b')
		{
                    fp = fopen("student.txt","a+");
                        char temp[100];
			printf("'b' pressed'\n");
			printf("Press any Option : \n");
		     printf("Press '0' for reding student 1 record\n");
		     printf("Press '1' for reding student 2 record\n");
		     printf("Press '2' for reding student 3 record\n");
			scanf("%c",&a);
			while (1)
			{
				if (a=='0')
				{
					printf("'0' pressed'\n");
                                        printf("Your Record : ");
                                        fgets(temp,100,fp);
                                        printf("%s",temp);
                                        printf("\n"); 
					break;
				}
				else if (a=='1')
				{
					printf("'1' pressed'\n");
                                        printf("Your Fellow Record : ");
                                        fseek( fp, 46, SEEK_SET );
                                        fgets(temp,100,fp);
                                        printf("%s",temp);
                                        printf("\n");
					break;
				}
				else if (a=='2')
				{
					printf("'2' pressed'\n");
                                         printf("Your Fellow Record : ");
                                        fseek( fp, 92, SEEK_SET );
                                        fgets(temp,100,fp);
                                        printf("%s",temp);
                                        printf("\n");
					break;
				}
				else
				{
				   printf("=>You have Entered wrong kay\n");
				   printf("Press any Option : \n");
				   printf("Press '0' for reding student 1 record\n");
					printf("Press '1' for reding student 2 record\n");
					printf("Press '2' for reding student 3 record\n");
					scanf("%c",&a);
				}
			}
                        fclose(fp);
			break;
		}
		else if (c=='c')
		{
                        fp = fopen("student.txt","r+");
			printf("'c' pressed'\n");
			printf("Press any Option : \n");
			printf("Press '0' for delete student 1 record\n");
			printf("Press '1' for delete student 2 record\n");
			printf("Press '2' for delete student 3 record\n");
                        scanf("%c",&a);
                        scanf("%c",&a);
			while (1)
			{
				if (a=='0')
				{
					printf("'0' pressed'\n");
                                        for(i=0;i<3;i++)
                                        {
                                           fgets(data[i],300,fp);
                                        }
                                        fclose(fp);
                                        //printf("%s",data[0]);
 					//printf("%s",data[1]);
					//printf("%s",data[2]);
                                        fp = fopen("student.txt","w");
                                        for(i=0;i<3;i++)
                                        {  
                                           if(i==0){
                                             fputs("null",fp);
                                             fputs("\n",fp);
                                           }
                                           else{
                                           //fprintf(fp,"%s\n",data[i]);
                                           fputs(data[i],fp);}
                                        }
                                        //fseek( fp, 0, SEEK_SET );
                                       // fputs("null",fp);
                                        printf("\n");
                                        printf("Your Record deleted successfully\n");
					break;
				}
				else if (a=='1')
				{
					printf("'1' pressed'\n");
                                        for(i=0;i<3;i++)
                                        {
                                           fgets(data[i],300,fp);
                                        }
                                        fclose(fp);
                                        //printf("%s",data[0]);
 					//printf("%s",data[1]);
					//printf("%s",data[2]);
                                        fp = fopen("student.txt","w");
                                        for(i=0;i<3;i++)
                                        {  
                                           if(i==1){
                                             fputs("null",fp);
                                             fputs("\n",fp);
                                           }
                                           else{
                                           //fprintf(fp,"%s\n",data[i]);
                                           fputs(data[i],fp);}
                                        }
                                        printf("Your Fellow 1 Record deleted successfully\n");
					break;
				}
				else if (a=='2')
				{
 					printf("'2' pressed'\n");
                                        for(i=0;i<3;i++)
                                        {
                                           fgets(data[i],300,fp);
                                        }
                                        fclose(fp);
                                        //printf("%s",data[0]);
 					//printf("%s",data[1]);
					//printf("%s",data[2]);
                                        fp = fopen("student.txt","w");
                                        for(i=0;i<3;i++)
                                        {  
                                           if(i==2){
                                             fputs("null",fp);
                                             fputs("\n",fp);
                                           }
                                           else{
                                           //fprintf(fp,"%s\n",data[i]);
                                           fputs(data[i],fp);}
                                        }
                                        printf("Your Fellow 2 Record deleted successfully\n");
					break;
				}
				else
				{
					printf("=>You have Entered wrong kay\n");
					printf("Press any Option : \n");
					printf("Press '0' for delete student 1 record\n");
					printf("Press '1' for delete student 2 record\n");
					printf("Press '2' for delete student 3 record\n");
					scanf("%c",&a);
				}
			}
                        fclose(fp);
			break;
		}
		else
		{
			printf("=>You have Entered wrong kay\n");
			printf("Press any Option : \n");
			printf("Press 'a' for adding students\n");
			printf("Press 'b' for reding students record\n");
			printf("Press 'c' for deleting students record\n");
			scanf("%s",&c);
		}
	}
	return 0;
}
